// src/sheets.js
const axios = require('axios');
const SCRIPT_URL = 'https://script.google.com/macros/s/AKfycbzIIeV9krvOnxfIpNwsFeerBSfe8sK-eyue6rF6m4mHDPaYTddwuv6ejZz8ikvAdl2TAA/exec'; // Replace with your Google Apps Script URL

async function logToSheet(data) {
  await axios.post(SCRIPT_URL, data);
}

module.exports = { logToSheet };