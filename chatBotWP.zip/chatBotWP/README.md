# WhatsApp Automation with Google Sheets

A simple Node.js application that automates WhatsApp conversations and stores responses in Google Sheets.

## Features
- ✅ Automated WhatsApp conversations
- ✅ Google Sheets integration
- ✅ Webhook verification
- ✅ Error handling
- ✅ Health monitoring

## Quick Start

### 1. Install Dependencies
```bash
npm install