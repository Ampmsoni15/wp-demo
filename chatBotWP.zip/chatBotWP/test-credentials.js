require("dotenv").config();
const axios = require("axios");

async function testCredentials() {
    console.log("🧪 Testing WhatsApp Business API credentials...\n");
    
    // Check if environment variables are set
    console.log("📋 Environment Variables Check:");
    console.log("WHATSAPP_TOKEN:", process.env.WHATSAPP_TOKEN ? "✅ Set" : "❌ Missing");
    console.log("PHONE_NUMBER_ID:", process.env.PHONE_NUMBER_ID ? "✅ Set" : "❌ Missing");
    console.log("VERIFY_TOKEN:", process.env.VERIFY_TOKEN ? "✅ Set" : "❌ Missing");
    console.log("GOOGLE_SCRIPT_URL:", process.env.GOOGLE_SCRIPT_URL ? "✅ Set" : "❌ Missing");
    console.log("");
    
    if (!process.env.WHATSAPP_TOKEN || !process.env.PHONE_NUMBER_ID) {
        console.log("❌ Missing required credentials. Please check your .env file.");
        return;
    }
    
    try {
        // Test API access by getting phone number info
        console.log("🔍 Testing WhatsApp API access...");
        const response = await axios.get(
            `https://graph.facebook.com/v19.0/${process.env.PHONE_NUMBER_ID}`,
            {
                headers: {
                    'Authorization': `Bearer ${process.env.WHATSAPP_TOKEN}`
                }
            }
        );
        
        console.log("✅ WhatsApp API Access Successful!");
        console.log("📞 Phone Number Info:");
        console.log("   Phone Number ID:", response.data.id);
        console.log("   Display Number:", response.data.display_phone_number);
        console.log("   Verified Name:", response.data.verified_name || "Not set");
        console.log("   Quality Rating:", response.data.quality_rating || "Not available");
        console.log("");
        
        // Test Google Apps Script (if URL is provided)
        if (process.env.GOOGLE_SCRIPT_URL) {
            console.log("🔍 Testing Google Apps Script connection...");
            try {
                const testData = {
                    phone: "test123456789",
                    name: "Test User",
                    secret: "123456"
                };
                
                const scriptResponse = await axios.post(process.env.GOOGLE_SCRIPT_URL, testData);
                console.log("✅ Google Apps Script Connection Successful!");
                console.log("Response:", scriptResponse.data);
            } catch (scriptError) {
                console.log("❌ Google Apps Script Test Failed:");
                console.log("Error:", scriptError.response?.data || scriptError.message);
            }
        }
        
        console.log("\n🎉 Setup appears to be working correctly!");
        console.log("💬 You can now test by sending a message to your WhatsApp Business number.");
        
    } catch (error) {
        console.log("❌ WhatsApp API Test Failed:");
        if (error.response) {
            console.log("Status:", error.response.status);
            console.log("Error:", JSON.stringify(error.response.data, null, 2));
            
            if (error.response.status === 401) {
                console.log("\n🔧 Fix: Check your WHATSAPP_TOKEN - it might be expired or invalid");
            } else if (error.response.status === 404) {
                console.log("\n🔧 Fix: Check your PHONE_NUMBER_ID - it might be incorrect");
            }
        } else {
            console.log("Error:", error.message);
        }
    }
}

testCredentials();