// app.js
const express = require('express');
const bodyParser = require('body-parser');
const { handleIncomingMessage } = require('./src/chatflow');
const app = express();
app.use(bodyParser.json());

app.post('/webhook', async (req, res) => {
  const message = req.body; // WhatsApp webhook payload
  await handleIncomingMessage(message);
  res.sendStatus(200);
});

app.listen(3000, () => console.log('Server running'));