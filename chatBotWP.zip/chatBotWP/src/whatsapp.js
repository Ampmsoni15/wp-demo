// src/whatsapp.js
const axios = require('axios');
const WHATSAPP_API_URL = 'https://graph.facebook.com/v17.0/611356515403656/messages';
const TOKEN = 'EAAR5LU36cXEBO3rUXgzL2EXdemnlkcK8AXOFOEdPcMLgqHNEVa9DNSARiCqOBNcqeGeuNDNwJUPxKLP5wtZAae2N2wd8gfBhOF7mCoMsAFtAL4zrxDKTEA3sEf4dfs3iywZBZAV4W57vxf2OZCrbLJP083v9z357gmu13m9ePqyZBWlM4YhTwhyDsILQSiAy0qAZDZD';

async function sendMessage(to, text) {
  const response = await axios.post(WHATSAPP_API_URL, {
    messaging_product: 'whatsapp',
    to,
    type: 'text',  // Add this
    text: { body: text }
  }, {
    headers: { 
      'Authorization': `Bearer ${TOKEN}`,
      'Content-Type': 'application/json'  // Add this
    }
  });
  
  return response;  // ← Add this line!
}
module.exports = { sendMessage };