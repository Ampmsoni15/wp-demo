// This code goes in Google Apps Script (script.google.com)
// Deploy as Web App with access for "Anyone"

function doPost(e) {
  try {
    // Parse the incoming data
    const data = JSON.parse(e.postData.contents);
    
    // Optional: Check secret for security
    const expectedSecret = "123456"; // Match this with your Node.js code
    if (data.secret !== expectedSecret) {
      return ContentService
        .createTextOutput(JSON.stringify({success: false, error: "Invalid secret"}))
        .setMimeType(ContentService.MimeType.JSON);
    }
    
    // Open the Google Sheet (replace with your sheet ID)
    const SHEET_ID = "YOUR_GOOGLE_SHEET_ID_HERE"; // Get this from your sheet URL
    const sheet = SpreadsheetApp.openById(SHEET_ID).getActiveSheet();
    
    // Add headers if the sheet is empty
    if (sheet.getLastRow() === 0) {
      sheet.getRange(1, 1, 1, 4).setValues([
        ["Timestamp", "Phone Number", "Name", "Status"]
      ]);
      
      // Format headers
      const headerRange = sheet.getRange(1, 1, 1, 4);
      headerRange.setFontWeight("bold");
      headerRange.setBackground("#4285f4");
      headerRange.setFontColor("white");
    }
    
    // Add the new row with data
    const timestamp = new Date();
    const phoneNumber = data.phone;
    const name = data.name;
    const status = "Completed";
    
    sheet.appendRow([timestamp, phoneNumber, name, status]);
    
    // Auto-resize columns for better visibility
    sheet.autoResizeColumns(1, 4);
    
    console.log(`Data saved: ${phoneNumber} - ${name}`);
    
    // Return success response
    return ContentService
      .createTextOutput(JSON.stringify({
        success: true, 
        message: "Data saved successfully",
        timestamp: timestamp,
        phone: phoneNumber,
        name: name
      }))
      .setMimeType(ContentService.MimeType.JSON);
    
  } catch (error) {
    console.error("Error:", error);
    return ContentService
      .createTextOutput(JSON.stringify({
        success: false, 
        error: error.toString(),
        message: "Failed to save data"
      }))
      .setMimeType(ContentService.MimeType.JSON);
  }
}

// Handle GET requests for testing
function doGet(e) {
  return ContentService
    .createTextOutput(JSON.stringify({
      message: "WhatsApp webhook handler is running",
      timestamp: new Date(),
      status: "active"
    }))
    .setMimeType(ContentService.MimeType.JSON);
}

// Test function to verify the script works
function testScript() {
  const testData = {
    postData: {
      contents: JSON.stringify({
        phone: "1234567890",
        name: "Test User",
        secret: "123456"
      })
    }
  };
  
  const result = doPost(testData);
  console.log(result.getContent());
}