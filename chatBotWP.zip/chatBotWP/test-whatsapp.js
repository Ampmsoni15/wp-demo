// WhatsApp Bot with Google Sheets Integration
const express = require('express');
const bodyParser = require('body-parser');
const { sendMessage } = require('./src/whatsapp'); // Your sendMessage function
const { google } = require('googleapis');

const app = express();
const port = 3000;

// Config
const VERIFY_TOKEN = '';
const SPREADSHEET_ID = '';
const SERVICE_ACCOUNT_PATH = './chatbot-467615-47cdaad96cd7.json';

// Middlewares
app.use(bodyParser.json());

// Track user conversation steps
const userStates = new Map();

// 🔧 Google Sheets Setup
async function initGoogleSheets() {
  const auth = new google.auth.GoogleAuth({
    keyFile: SERVICE_ACCOUNT_PATH,
    scopes: ['https://www.googleapis.com/auth/spreadsheets'],
  });
  const sheets = google.sheets({ version: 'v4', auth });
  return sheets;
}

// ✅ Save to Google Sheet
async function saveToGoogleSheets(phoneNumber, data) {
  try {
      console.log(`📝 Saving data to sheet for ${phoneNumber}:`, data);

    const sheets = await initGoogleSheets();
    const timestamp = new Date().toLocaleString('en-IN', { timeZone: 'Asia/Kolkata' });

    const values = [[
      timestamp,
      phoneNumber,
      data.customerType || '',
      data.name || '',
      data.location || '',
      data.requirement || ''
    ]];

    await sheets.spreadsheets.values.append({
      spreadsheetId: SPREADSHEET_ID,
      range: 'Sheet1!A:F',
      valueInputOption: 'RAW',
      insertDataOption: 'INSERT_ROWS',
      resource: { values },
    });

    console.log(`✅ Saved data for ${phoneNumber}`);
  } catch (err) {
    console.error('❌ Google Sheets Error:', err);
  }
}

// 🧠 Conversation Flow


async function handleConversation(from, text) { 
  const phoneNumber = from;
  text = text.trim().toLowerCase();

  if (!userStates[phoneNumber]) {
    userStates[phoneNumber] = { step: 'initial', data: {} };
    console.log(`🆕 New user initialized: ${phoneNumber}`);
  }

  const state = userStates[phoneNumber];
  console.log(`📥 Incoming message from ${phoneNumber}: "${text}", current step: ${state.step}`);

  switch (state.step) {
    case 'initial':
      if (text === 'hello' || text === 'hi') {
        await sendMessage(phoneNumber, `Welcome! 👋\nAre you a Customer or Dealer?\n\nPlease type:\n• Customer\n• Dealer`);
        state.step = 'waiting_for_type';
        console.log(`🔄 Step changed to: waiting_for_type`);
      } else if (text === 'customer' || text === 'dealer') {
        state.data.customerType = text.charAt(0).toUpperCase() + text.slice(1);
        await sendMessage(phoneNumber, `Great! You selected: ${state.data.customerType} ✅\n\nWhat's your name?`);
        state.step = 'waiting_for_name';
        console.log(`🔄 Step changed to: waiting_for_name`);
      } else {
        await sendMessage(phoneNumber, 'Please type "hello" to begin. 😊');
        console.log(`ℹ️ Unrecognized input at initial step`);
      }
      break;

    case 'waiting_for_type':
      console.log(`🧩 Inside: waiting_for_type`);
      if (text === 'customer' || text === 'dealer') {
        state.data.customerType = text.charAt(0).toUpperCase() + text.slice(1);
        await sendMessage(phoneNumber, `Great! You selected: ${state.data.customerType} ✅\n\nWhat's your name?`);
        state.step = 'waiting_for_name';
        console.log(`🔄 Step changed to: waiting_for_name`);
      } else {
        await sendMessage(phoneNumber, 'Please type either:\n• Customer\n• Dealer');
        console.log(`⚠️ Invalid customer type entered`);
      }
      break;

    case 'waiting_for_name':
      console.log(`🧩 Inside: waiting_for_name`);
      state.data.name = text;
      await sendMessage(phoneNumber, `Hi ${state.data.name}! 📍 Where are you located?`);
      state.step = 'waiting_for_location';
      console.log(`🔄 Step changed to: waiting_for_location`);
      break;

    case 'waiting_for_location':
      console.log(`🧩 Inside: waiting_for_location`);
      state.data.location = text;
      await sendMessage(phoneNumber, `Got it. 📌 Please tell me your requirement.`);
      state.step = 'waiting_for_requirement';
      console.log(`🔄 Step changed to: waiting_for_requirement`);
      break;

    case 'waiting_for_requirement':
      console.log(`🧩 Inside: waiting_for_requirement`);
      state.data.requirement = text;

      const dataToSave = {
        customerType: state.data.customerType,
        name: state.data.name,
        location: state.data.location,
        requirement: state.data.requirement
      };

      console.log(`📤 Saving data to Google Sheet:`, dataToSave);

      try {
        await saveToGoogleSheets(phoneNumber, dataToSave);
        await sendMessage(phoneNumber, `✅ Thank you ${state.data.name}! Your data has been saved. We will contact you soon.`);
        state.step = 'completed';
        console.log(`✅ Conversation completed for: ${phoneNumber}`);
      } catch (err) {
        console.error(`❌ Failed to save to Google Sheet:`, err.message);
        await sendMessage(phoneNumber, `❌ Sorry, something went wrong saving your data. Please try again later.`);
      }
      break;

    case 'completed':
      console.log(`🔁 Restarting conversation for: ${phoneNumber}`);
      await sendMessage(phoneNumber, `Do you want to start again? Type "hello"`);
      userStates[phoneNumber] = { step: 'initial', data: {} };
      break;

    default:
      console.log(`❓ Unknown step for ${phoneNumber}: ${state.step}`);
      await sendMessage(phoneNumber, `❓ I'm not sure where we are. Let's start over. Type "hello" to begin.`);
      userStates[phoneNumber] = { step: 'initial', data: {} };
      break;
  }
}


// 🔗 Webhook Verification (Meta/Facebook)
app.get('/webhook', (req, res) => {
  const mode = req.query['hub.mode'];
  const token = req.query['hub.verify_token'];
  const challenge = req.query['hub.challenge'];

  if (mode === 'subscribe' && token === VERIFY_TOKEN) {
    console.log('✅ Webhook verified');
    res.status(200).send(challenge);
  } else {
    console.log('❌ Webhook verification failed');
    res.sendStatus(403);
  }
});

// 📩 WhatsApp Webhook Receiver (Meta Live Integration)
app.post('/webhook', async (req, res) => {
  const body = req.body;

  if (body.object === 'whatsapp_business_account') {
    body.entry?.forEach(entry => {
      entry.changes?.forEach(change => {
        if (change.field === 'messages') {
          const messages = change.value.messages;
          if (messages) {
            messages.forEach(async msg => {
              if (msg.type === 'text') {
                const from = msg.from;
                const text = msg.text.body;
                await handleConversation(from, text);
              }
            });
          }
        }
      });
    });
  }

  res.sendStatus(200);
});

// 🧪 Local Testing Endpoint
app.post('/test-local', async (req, res) => {
  const { from, text } = req.body;
  if (!from || !text) {
    return res.status(400).json({ error: 'from and text are required' });
  }
  await handleConversation(from, text);
  res.send('✅ Message processed');
});

// 🧠 Health Check
app.get('/', (req, res) => {
  res.json({
    status: '✅ WhatsApp Bot is running',
    activeUsers: userStates.size,
    timestamp: new Date().toISOString()
  });
});

// Start Server
app.listen(port, () => {
  console.log(`🚀 Server running at http://localhost:${port}`);
});

// Graceful Exit
process.on('SIGINT', () => {
  console.log('🛑 Server shutting down');
  process.exit();
});
