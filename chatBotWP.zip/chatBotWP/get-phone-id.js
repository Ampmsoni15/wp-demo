// Script to get WhatsApp Phone Number ID using your token
// npm install axios

const axios = require('axios');

const WHATSAPP_TOKEN = 'EAAR5LU36cXEBO3rUXgzL2EXdemnlkcK8AXOFOEdPcMLgqHNEVa9DNSARiCqOBNcqeGeuNDNwJUPxKLP5wtZAae2N2wd8gfBhOF7mCoMsAFtAL4zrxDKTEA3sEf4dfs3iywZBZAV4W57vxf2OZCrbLJP083v9z357gmu13m9ePqyZBWlM4YhTwhyDsILQSiAy0qAZDZD';

// Function to get WhatsApp Business Account ID
async function getWhatsAppBusinessAccountId() {
    try {
        const response = await axios.get('https://graph.facebook.com/v17.0/me', {
            headers: {
                'Authorization': `Bearer ${WHATSAPP_TOKEN}`
            }
        });
        
        console.log('✅ WhatsApp Business Account Info:');
        console.log('Account ID:', response.data.id);
        console.log('Account Name:', response.data.name);
        
        return response.data.id;
    } catch (error) {
        console.error('❌ Error getting business account:', error.response?.data || error.message);
        throw error;
    }
}

// Function to get Phone Number ID
async function getPhoneNumberId(businessAccountId = '122118631970923157') {
    try {
        const response = await axios.get(
            `https://graph.facebook.com/v17.0/${businessAccountId}/phone_numbers`,
            {
                headers: {
                    'Authorization': `Bearer ${WHATSAPP_TOKEN}`
                }
            }
        );
        
        console.log('\n📱 Phone Numbers:');
        
        if (response.data.data && response.data.data.length > 0) {
            response.data.data.forEach((phone, index) => {
                console.log(`\n--- Phone Number ${index + 1} ---`);
                console.log('Phone Number ID:', phone.id);
                console.log('Display Name:', phone.display_phone_number);
                console.log('Verified Name:', phone.verified_name);
                console.log('Status:', phone.status);
                console.log('Quality Rating:', phone.quality_rating);
            });
            
            // Return the first phone number ID
            return response.data.data[0].id;
        } else {
            console.log('❌ No phone numbers found');
            return null;
        }
    } catch (error) {
        console.error('❌ Error getting phone numbers:', error.response?.data || error.message);
        throw error;
    }
}

// Function to test sending a message (optional)
async function testMessage(phoneNumberId, to, message) {
    try {
        const response = await axios.post(
            `https://graph.facebook.com/v17.0/${phoneNumberId}/messages`,
            {
                messaging_product: 'whatsapp',
                to: to,
                type: 'text',
                text: {
                    body: message
                }
            },
            {
                headers: {
                    'Authorization': `Bearer ${WHATSAPP_TOKEN}`,
                    'Content-Type': 'application/json'
                }
            }
        );
        
        console.log('\n✅ Test message sent successfully!');
        console.log('Message ID:', response.data.messages[0].id);
        return response.data;
    } catch (error) {
        console.error('❌ Error sending test message:', error.response?.data || error.message);
        throw error;
    }
}

// Main function
async function main() {
    try {
        console.log('🚀 Getting WhatsApp Phone Number ID...\n');
        
        // Use your known Account ID directly
        const businessAccountId = '122118631970923157';
        console.log('✅ Using Account ID:', businessAccountId);
        
        // Get Phone Number ID
        const phoneNumberId = await getPhoneNumberId(businessAccountId);
        
        if (phoneNumberId) {
            console.log('\n🎉 SUCCESS!');
            console.log('═'.repeat(50));
            console.log(`PHONE_NUMBER_ID: ${phoneNumberId}`);
            console.log('═'.repeat(50));
            
            // Uncomment below to test sending a message
            // Replace with a valid WhatsApp number (with country code, no + sign)
            // await testMessage(phoneNumberId, '919876543210', 'Hello from WhatsApp API!');
        }
        
    } catch (error) {
        console.error('\n❌ Failed to get phone number ID');
        
        // Common error solutions
        if (error.response?.data?.error?.code === 190) {
            console.log('\n💡 Solution: Your access token might be invalid or expired');
            console.log('- Check if token is correct');
            console.log('- Generate a new token from Meta Developer Console');
        }
        
        if (error.response?.data?.error?.code === 100) {
            console.log('\n💡 Solution: Permission issue');
            console.log('- Make sure WhatsApp Business API is added to your Meta app');
            console.log('- Check if you have proper permissions');
        }
    }
}

// Run the script
main();

/* 
USAGE:

1. Install axios:
   npm install axios

2. Replace 'your-whatsapp-access-token-here' with your actual token

3. Run the script:
   node get-phone-id.js

4. Copy the PHONE_NUMBER_ID from the output

5. Use it in your main WhatsApp bot code

WHAT THIS SCRIPT DOES:
- Gets your WhatsApp Business Account info
- Lists all phone numbers associated with your account
- Shows Phone Number ID, display name, status, etc.
- Optionally tests sending a message

COMMON ERRORS & SOLUTIONS:
- Error 190: Invalid/expired token → Generate new token
- Error 100: Permission denied → Check app permissions
- No phone numbers: Add phone number in Meta Business Manager

The Phone Number ID will look like: 109876543210987
*/