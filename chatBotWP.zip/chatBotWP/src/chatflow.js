// src/chatflow.js
const { sendMessage } = require('./whatsapp');
const { logToSheet } = require('./sheets');

const chatTree = {
  start: {
    reply: "Hello! What's your name?",
    next: 'getName'
  },
  getName: {
    reply: name => `Nice to meet you, ${name}!`,
    log: true,
    next: null
  }
};

async function handleIncomingMessage(message) {
  const phone = message.from;
  const text = message.text.body;
  let step = 'start'; // You'd track user state in a DB or in-memory

  if (text.toLowerCase() === 'hello') {
    await sendMessage(phone, chatTree.start.reply);
    step = chatTree.start.next;
  } else {
    // Assume previous step was getName
    await sendMessage(phone, chatTree.getName.reply(text));
    await logToSheet({ phone, step: 'getName', response: text, status: 'Completed' });
  }
}

module.exports = { handleIncomingMessage };